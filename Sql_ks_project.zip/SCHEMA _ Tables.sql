CREATE TABLE Products (
    ProductID      VARCHAR(10) PRIMARY KEY,
    ProductName    NVARCHAR(255),
    ProductGroup   NVARCHAR(100),
    Brand          NVARCHAR(100),
    Price          DECIMAL(10,2)
);

CREATE TABLE Stock (
    PurchaseID      VARCHAR(20) PRIMARY KEY,
    Location        NVARCHAR(100),
    ProductID       VARCHAR(10),
    OrderDate       DATE,
    DeliveryDate    DATE,
    OrderQuantity   INT,
    StockBalance    INT,
    StockValue      DECIMAL(18,2),
    CONSTRAINT FK_Stock_Products
        FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

CREATE TABLE Sales (
    SalesDate     DATE,
    ProductID     VARCHAR(10),
    Apsis         INT,
    Basalt        INT,
    Ceres         INT,
    Total         INT,
    CONSTRAINT FK_Sales_Products
        FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);