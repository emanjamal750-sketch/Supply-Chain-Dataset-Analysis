BULK INSERT Products
FROM 'C:\Import\product.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
);


BULK INSERT Stock
FROM 'C:\Import\stock.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001',
    TABLOCK
);

BULK INSERT Sales
FROM 'C:\Import\sales.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '0x0a',
    CODEPAGE = '65001',
    TABLOCK
);

SELECT COUNT(*) FROM Products;
SELECT COUNT(*) FROM Stock;
SELECT COUNT(*) FROM Sales;